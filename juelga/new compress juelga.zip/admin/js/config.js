//firebase configerations 

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCuR5hhOLBt1BBp8QUO9QSQ6aZtiLikkIY",
  authDomain: "juelga-solutions.firebaseapp.com",
  databaseURL: "https://juelga-solutions-default-rtdb.firebaseio.com",
  projectId: "juelga-solutions",
  storageBucket: "juelga-solutions.appspot.com",
  messagingSenderId: "393136340404",
  appId: "1:393136340404:web:bc2bddcc19e886992106e1",
  measurementId: "G-64ERG1EZ1P"

};
  
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);


    